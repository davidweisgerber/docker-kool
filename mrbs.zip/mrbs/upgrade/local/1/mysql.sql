# $Id: mysql.sql 1072 2009-03-25 13:30:48Z cimorrison $

INSERT INTO %DB_TBL_PREFIX%variables (variable_name, variable_content)
  VALUES ( 'local_db_version', '1');
