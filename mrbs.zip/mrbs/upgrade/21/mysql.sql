# $Id: mysql.sql 1571 2010-11-02 15:10:18Z cimorrison $
