# $Id: mysql.sql 1131 2009-06-25 22:33:26Z jberanek $
